Assignment # 1
JavaScript/TypeScript Basic Operations & Concepts

Let vs Const vs Var
Q1

console.log(x);
var x = 5;


Output: undefined

Explanation: the variable var should be declared before calling it.

Q2

sayHello();
function sayHello(){
    console.log("Hello!!!!!")
}


Output: Hello!!!!!

Explanation: sayHello is a global variable.

Q3

console.log(x)
let x = 5;


Output: ReferenceError: Cannot access 'x' before initialization

Explanation: x should be initialize before calling it.

Q4

console.log(x)
const x = 5;


Output: ReferenceError: Cannot access 'x' before initialization

Explanation: x should be initialize before calling it.

Q5

const x;
x = 5;
console.log(x)


Output: SyntaxError: Missing initializer in const declaration

Explanation: value of x which is 5 here, should be declared with const.
Q6

var x = 6;
var x = 5;
console.log(x)


Output: 5

Explanation: value of var is redeclared here, so it shows the new value of x.

Q7

let x= 6;
let x = 5;
console.log(x)


Output: SyntaxError: Identifier 'x' has already been declared

Explanation: while using let, one cannot redeclare a variable.

Q8

const x= 6;
const x = 5;
console.log(x)


Output: SyntaxError: Identifier 'x' has already been declared

Explanation: One cannot redeclare a variable, using const.

Q9

Considering the above outputs what is the difference between var, let and const?

Answer: var can be redeclared. On the other hand, let and const keywords cannot be redeclared.

Ternary Operator
Q1

Write a function that takes a string as input. If that string can be converted to a number return true else return false.

For example
i) Input: "12"
   Output: true
ii) Input: "a"
    Output: false




// Write your code here
function StringRead(value) {
        for (let i = 0; i < value.length; i++)
        return (value[i] < '0' || value[i] > '9') ? false : true;
    };
console.log(StringRead("a"));

Q2

Write a function that takes scores as input and returns a student's grade. If the score is greater or equal to 80 grade must be "A", if the score is between 70 (including) and 80 grade must be "B", if the score is between 50 (including) and 70 grade must be "C", if the score is between 30 (including) and 50 grade must be "D" else grade must be "F"

For example
i) Input: "80"
   Output: "A"

ii) Input: "50"
    Output: "C"



// Write your code here
function StudentGrade(marks){
    return  marks>=80 ? "A" : marks>=70 && marks<80 ? 
"B" : marks>=50 && marks<70 ? "C" : marks>=30 && marks<50 ? "D" : "F"};
console.log(StudentGrade(82));
Q3

Write a function that takes a string as an input. If a string is passed as a parameter the string is returned if nothing is passed as a parameter it should return the text "enter a string".

For example
i) Input: undefined
   Output: "enter a string"

ii) Input: "50"
    Output: "50"



/// Write your code in JS
function StringCheck(value) {
  return parseInt(value) ? value : "enter a string"
};
console.log(StringCheck(undefined));

For loops
Q1

Write a function that takes an array as input. Add 10 to each element of the array. Print the execution time of the for loop execution.

For example
i) Input: [11,12,13,14]
   Output: 
      [21,22,23,24]
      for-loop: 4.175ms





// Write your code here
function AddArray(value) {
  const startTime = performance.now();
  for (let i = 0; i < value.length; i++) {
    value[i] += 10;
  }
  const endTime = performance.now();
  const executionTimeMs = endTime - startTime;
  return { array: value, executionTimeMs };
}
const inputArray = [11, 12, 13, 14];
const { array: outputArray, executionTimeMs } = 
AddArray(inputArray);
console.log("Input Array:", inputArray);
console.log("Output Array:", outputArray);
console.log(`for-loop Execution Time: ${executionTimeMs.toFixed(3)}ms`);

Q2

let x = [11,12,113,14]
for(let i in x){console.log(i)}


Output:
›0
›1
›2
›3
Explanation: This code shows the output of the position of each element in an array, using an in statement.
Q3

let x = [11,12,113,14]
for(let i of x){console.log(i)}


Output: 
›11
›12
›113
›14
Explanation: This code shows the output of the element present in an array, using of statement.

Q4

Write a function that takes an array as input. Add 10 to each element of the array and create a new array with the updated elements. Print the execution time of the for loop execution.

NOTE: You are not allowed to use a for/while loop.

For example,
i) Input: [11,12,13,14]
   Output: 
      [21,22,23,24]
      default: 4.175ms


// Write your code here.
function AddArray(value) {
  const startTime = performance.now();
  const updatedArray = value.map(element => element + 10);
  const endTime = performance.now();
  const executionTimeMs = endTime - startTime;
  return { array: updatedArray, executionTimeMs };
}
const inputArray = [11, 12, 13, 14];
const { array: outputArray, executionTimeMs } = AddArray(inputArray);
console.log("Input:", inputArray);
console.log("Output:", outputArray);
console.log(`default: ${executionTimeMs.toFixed(3)}ms`);

Array Manipulation
Q1

Write a function that takes an array as input. Find the numbers that have pairs in the array. Return a maximum number that has a pair in the array. If there is no pair in the array return -1.

NOTE: Do not use nested loops for making pairs.

For example,
i) Input: [11,12,13,14,11,12,12,14,13]
   Output: 14
ii) Input: [11,12,13,13,13]
    Output: -1


// Write your code here
function findMaxNumber(value) {
  const numberFrequency = value.reduce((freqObj, number) => {
    freqObj[number] = (freqObj[number] || 0) + 1;
    return freqObj;
  }, {});
  
  let maxNumberWithPair = -1;
  for (const number in numberFrequency) {
    if (numberFrequency[number] >= 2 && parseInt(number) > maxNumberWithPair) {
      maxNumberWithPair = parseInt(number);
    }
  }
  return maxNumberWithPair;
}
console.log(findMaxNumber([11, 12, 13, 14, 11, 12, 12, 14, 13]));
console.log(findMaxNumber([11, 12, 13, 13, 13]));

Q2

Write a function that takes an array as input. Sum the elements of the array and return the sum. 

NOTE: Do not use any loops for the sum.

For example,
i) Input: [11,12,1]
   Output: 24


// Write your code here
function sumArray(value) {
  const sum = value.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
  return sum;
}
console.log(sumArray([11, 12, 1]));

Q3

Write a function that takes an array as input. Concat the element of the array to make one string.

NOTE: Do not use any loops for concating elements of the array.

For example,
i)  Input: ["s", "u", "n"]
    Output: "sun"
ii) Input: ["i", "n", " ", "the", " ", "sky"]
    Output: "in the sky"


// Write your code here
function concatArray(value) {
  const concatenatedString = value.join("");
  return concatenatedString;
};
console.log(concatArray(["s", "u", "n"]));
console.log(concatArray(["i", "n", " ", "the", " ", "sky"]));

Q4

Write a function that takes an array as input. Manipulate an array in such a way that the last 3 elements are removed from the original array.

NOTE: Do not use any loops.

For example,
i)  Input: [11,12,13,14,16,17]
    Output: [11,12,13]
ii) Input: [11,12,13,14]
    Output: [11]


// Write your code here
function removeElements(value) {
  const modifiedArray = value.slice(0, value.length - 3);
  return modifiedArray;
};
console.log(removeElements([11, 12, 13, 14, 16, 17]));
console.log(removeElements([11, 12, 13, 14]));
Q5

Write a function that takes an array as input. Create a sub-array in which the last 3 elements of the original array are not present but the original array must remain the same.

NOTE: Do not use any loops.

For example,
i)  Input: [11,12,13,14,16,17]
    Output:
    [11,12,13,14,16,17]
    [11,12,13]
ii) Input: [11,12,13,14]
    Output:
    [11,12,13,14]
    [11]


// Write your code here
function SubArray(value) {
  const subArray = value.slice(0, value.length - 3);
  console.log(value);
  console.log(subArray);
};
SubArray([11, 12, 13, 14, 16, 17]);
SubArray([11, 12, 13, 14]);
Q6

Write a function that takes an array as input. Sort the array in ascending order and return the sorted array.

NOTE: Do not use any loops.

For example,
i)  Input: [11,4,2,9,21]
    Output: [2,4,9,11,21]


// Write your code here
function sortArray(value) {
  const sortedArray = value.slice().sort((a, b) => a - b);
  return sortedArray;
};
const inputArray = [11, 4, 2, 9, 21];
const sortedArray = sortArray(inputArray);
console.log(inputArray);
console.log(sortedArray);

Q7

Write a function that takes an array as input. Sort the array in descending order and return the sorted array.

NOTE: Do not use any loops.

For example,
i)  Input: [11,4,2,9,21]
    Output: [21,11,9,4,2]

// Write your code here
function sortArrayD(value) {
  const sortedArray = value.slice().sort((a, b) => b - a);
  return sortedArray;
};
const inputArray = [11, 4, 2, 9, 21];
const sortedArray = sortArrayD(inputArray);
console.log(inputArray);
console.log(sortedArray);

Object Manipulation
Q1

Write a function that takes two objects as input. Concat the second object to the first object.


For example,
i) Input: 
  {name: "John Doe", age: 30}
  {address: "123 Main Street"}

   Output: {name: "John Doe", age: 30, address: "123 Main Street"}

// Write your code here
function concatenateO(obj1, obj2) {
  const concatenatedObject = Object.assign({}, obj1, obj2);
  return concatenatedObject;
};
const obj1 = { name: "John Doe", age: 30 };
const obj2 = { address: "123 Main Street" };
const concatenatedObject = concatenateO(obj1, obj2);
console.log(obj1);
console.log(obj2);
console.log(concatenatedObject);
Q2

Write a function that takes two strings as parameters. Create a function within that object that takes those two parameters and returns "Hello firstString, lastString."
 
For example,
i) Input: Usman, Ghani

   Output: "Hello Usman , Ghani."

// Write your code here
const greetingF = {
  greet: function(firstString, lastString) {
    return `Hello ${firstString}, ${lastString}.`;
  }
};
const fName = "Usman";
const lName = "Ghani";
const greetingMessage = greetingF.greet(fName, lName);
console.log(fName);
console.log(lName);
console.log(greetingMessage);

Q3

Write a function that takes an object as a parameter. Create a function within the object that returns firstName and lastName.
 
For example,
i) Input:  {firstName: "John", lastName: "Doe", age: 30}

   Output: "John Doe"



// Write your code here
const personI = {
  fName: "John",
  lName: "Doe",
  age: 30,
  getFullName: function() {
    return `${this.fName} ${this.lName}`;
  }
};
const fullName = personI.getFullName();
console.log(fullName);

Q4

Write a function that takes an object as a parameter. Print the keys and values of the object inside the function.

Note: Do not use any loops to iterate the object.
 
For example,
i) Input:  {firstName: "John", lastName: "Doe", age: 30}

   Output: 
  [firstName, lastName, age]
  ["John", "Doe", 30]

// Write your code here
function printObject(obj) {
  const keysArray = Object.keys(obj);
  const valuesArray = Object.values(obj);
  console.log(keysArray);
  console.log(valuesArray);
};
const personInfo = { firstName: "John", lastName: "Doe", age: 30 };
printObject(personInfo);



Q5

Write a function that takes two arrays as a parameter. Combine those two arrays to create an object.

Note: Do not use any loops to iterate the arrays.
 
For example,
i) Input:  
  [firstName, lastName, age]
  ["John", "Doe", 30]
   Output: {firstName: "John", lastName: "Doe", age: 30}



// Write your code here
function combineArrays(keysArray, valuesArray) {
  const combinedObject = keysArray.reduce((obj, key, index) => {
    obj[key] = valuesArray[index];
    return obj;
  }, {});
  return combinedObject;
}
const keysArray = ["firstName", "lastName", "age"];
const valuesArray = ["John", "Doe", 30];
const combinedObject = combineArrays(keysArray, valuesArray);
console.log(combinedObject);

