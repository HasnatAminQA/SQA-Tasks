/*var myName = "Hasnat Amin";
var myStr = "Hello, my name is " + myName + ", how are you?";
console.log(myStr);*/


/*var someAdjective = "worthwhile";
var myStr = "Learning to code is ";
myStr += someAdjective;
console.log(myStr);

var firstNameLength = 0;
var firstName = "Ada";

firstNameLength = firstName.length;
console.log (firstNameLength);*/

/*var myStr = "Jello World";

myStr[0] = "Hello World"*/

/*var firstName = "Ada";
var lastLetteroffirstName = firstName[firstName.length - 1];
console.log(lastLetteroffirstName);

var lastName = "Lovelace";
var secondToLastLetterOfLastName = lastName[lastName.length - 2];
console.log(secondToLastLetterOfLastName);*/



/*function wordBlanks(myNoun, myAdjective, myVerb, myAdverb) {
    var result = "";
    result += "The " + myAdjective + " " + myNoun + " " + myVerb + " to the store" + " " + " " + myAdverb + ".";
    return result;   
}

console.log(wordBlanks("dog", "big", "ran", "quickly"));
//console.log(wordBlanks("bike", "slow", "flew", "slowly"));
*/


/*var myArray = ["Hasnat Amin", 1];
console.log(myArray);

var myArray = [["the universe", 42], ["everything", 101010]];
console.log(myArray); 

var myArray = [50, 60, 70];
myArray[0] = 45;
console.log(myArray)*/

/*var myArray = [[1,2,3], [4,5,6], [7,8,9], [10,11,12]];
var myData = myArray[3][1];
console.log(myData);

var myArray = [["John", 23], ["cat", 2]];
myArray.push(["dog", 3]);
console.log(myArray);


var myArray = [["John", 23], ["cat", 2]];
var removedFromMyArray = myArray.pop();
console.log(removedFromMyArray);
console.log(myArray)

var myArray = [["John", 23], ["dog", 3]];
var removedFromMyArray = myArray.shift();

console.log(myArray);
console.log(removedFromMyArray);

var myArray = [["John", 23], ["Furqan", 3]];
myArray.unshift(["Hasnat", 84]);
console.log(myArray); */

/*var myList = [["cereal", 3], ["milk", 2], ["bananas", 3], ["juice", 2], ["eggs", 12]];
console.log(myList);



function reusableFunction(){
    console.log("Hi World");
}

reusableFunction(); 


function solution(param1, param2) {
    
    console.log(param1 + param2); 

}

solution(10, 5) 

var myGlobal = 10;

function fun1() {
    
 oopsGlobal = 5;
}

function fun2(){
    
    var output = "";
    if (typeof myGlobal != "undefined") {
        output += "myGlobal: " + myGlobal;   
    }
    if (typeof oopsGlobal != "undefined"){
        output +="oopsGlobal: " + oopsGlobal;   
    }
    console.log(output);
}
fun1();
fun2();

function myLocalScope(){
    var myVar = 5;
    console.log(myVar);
}
myLocalScope(); 

var outerWear = "T-Shirt";

function myOutfit() {
    var outerWear = "sweater";
    return outerWear;   
}

console.log(myOutfit());
console.log(outerWear); 

function timesFive(num) {
    return num * 5;
}
console.log(timesFive(5)); 

var sum = 0;
function addFive(){
    sum +=5;
} 

var changed = 0;
function change(num) {
    return (num + 5) / 3;
}

changed = change(10);
console.log(changed);

function nextInLine(arr, item){
    arr.push(item);
    return arr.shift();
        
}
var testArr = [1,2,3,4,5];

console.log("Before: " + JSON.stringify(testArr));
console.log(nextInLine(testArr, 6));
console.log("After: " + JSON.stringify(testArr));


function welcomeToBooleans(){
    return true;
}


function trueOrFalse(isItTrue) {
    if (isItTrue) {
        return "Yes, it's true";
    }
    return "No, it's False";
}
console.log(trueOrFalse(false));


function testEqual(val) {
    if (val == 12) {
        return "Equal";
    }
    return "Not Equal";
}

console.log(testEqual(10));


function testStrict(val){
    if (val === 7) {
        return "Equal";
    }
    return "Not Equal";
}

console.log(testStrict('7'));


function  compareEquality(a,b){
    if (a===b) {
        return "Equal";
    }
    return "Not Equal";
}

console.log(compareEquality(10, "10"));
*/

function  testNotEqual(val){
    if (val != 99) {
        return "Not Equal";
    }
    return "Equal";
}

console.log(testNotEqual(99));
